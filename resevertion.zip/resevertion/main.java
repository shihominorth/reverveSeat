package resevertion;

public class main {
	static table table = new table();
	static askClass askClass = new askClass();
	static reserveFirst reserveFirst = new reserveFirst();
	static checkAllReserved checkAllReserved = new checkAllReserved();
	
	public static void main(String[] args) {
		
		table.firstClassSeat();
		table.economySeat();
		
		askClass.askClass();
		
		
		
		
	}
}
