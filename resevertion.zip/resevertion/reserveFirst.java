package resevertion;
import java.util.Scanner;

public class reserveFirst {
	static Scanner sc = new Scanner(System.in);
	static table table = new table();
	static reserveFirst reserveFirst = new reserveFirst();
	static String alphabet;
	static int num;
	static int x;
	static int y;
	
	public static void reserve() {
		System.out.println();
		System.out.println("Where do you want to make a reserve?");
		
		System.out.println("Which alphabet is the seat you want?");
		alphabet = sc.next();
		
		System.out.println("Which number is the seat you want?");
		num = sc.nextInt();
		
		if (alphabet.equals("A")) {
			x = 0;
		} 
		else if (alphabet.equals("B")) {
			x = 5;
		}
		else if (alphabet.equals("C")) {
			x = 9;
		}
		else {
			reserveFirst.reserve();
		}
		
		if (num == 0) {
			y = num;
		}
		else if (num == 1) {
			y = 2;
		} else {
			reserveFirst.reserve();
		}
	}
	
	public static void initReserve() {
		
		if( (y == 0 && x == 0) || (y == 0 && x == 5) || (y == 0 && x == 9)
				|| (y == 2 && x == 0) || ( y == 2 && x == 5) || (y == 2 && x == 9) ){
			
			table.firstClassGrid[y][x] = 1;
			table.firstClassGrid[y][x + 1] = 1;
			table.firstClassGrid[y + 1][x] = 1;
			table.firstClassGrid[y + 1 ][x + 1] = 1;
		}
		
		
	}
	
	public static void reservedSeat() {
		
		System.out.println("first Class.");
		System.out.println();
		
		for (int i = 0; i < 12; i++) {
			if (i == 0) {
				System.out.print("  A");
			}
			else if (i == 5) {
				System.out.print("B");
				
			}
			else if (i == 10) {
				System.out.println("C");
			} else {
				System.out.print(" ");
			};
		}
		
		for (int i = 0; i < 4; i++) {
			
			System.out.println();
			
			if (i == 0 ) {
				System.out.print(i + " ");
			}
			else if (i == 2) {
				System.out.print(i - 1 + " ");
			}
			else {
				System.out.print("  ");
			}
			
			for (int j = 0; j < 12; j++) {
				if (table.firstClassGrid[i][j] == 0) {
					System.out.print("F");
				}
				else if (table.firstClassGrid[i][j] == 1) {
					System.out.print("@");
				}
				else {
					System.out.print(" ");
				}
			}
		}
		
		}
	
}
