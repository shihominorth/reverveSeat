package resevertion;

import java.util.Scanner;

public class table {
	static int[][]  economyGrid = {
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
			{0,0,9,9,0,0,0,9,9,0,0,},
	};
	
	static int[][] firstClassGrid = {
			{0,0,9,9,9,0,0,9,9,9,0,0},
			{0,0,9,9,9,0,0,9,9,9,0,0},
			{0,0,9,9,9,0,0,9,9,9,0,0},
			{0,0,9,9,9,0,0,9,9,9,0,0},
	};
	
	public void firstClassSeat() {
		System.out.println("first Class.");
		System.out.println();
		
		for (int i = 0; i < 12; i++) {
			if (i == 0) {
				System.out.print("  A");
			}
			else if (i == 5) {
				System.out.print("B");
				
			}
			else if (i == 10) {
				System.out.println("C");
			} else {
				System.out.print(" ");
			};
		}
		
		for (int i = 0; i < 4; i++) {
			
			System.out.println();
			
			if (i == 0 ) {
				System.out.print(i + " ");
			}
			else if (i == 2) {
				System.out.print(i - 1 + " ");
			}
			else {
				System.out.print("  ");
			}
			
			for (int j = 0; j < 12; j++) {
				if (firstClassGrid[i][j] == 0) {
					System.out.print("F");
				}
				else {
					System.out.print(" ");
				}
			}
		}
		}
		
		public void economySeat() {
			System.out.println();
			System.out.println();
			System.out.println("Economy");
			System.out.println();
			
			for (int i = 0; i < 11; i++) {
				
				switch (i) {
				case 0:
					System.out.print("  A");
					break;

				case 1:
					System.out.print("B");
					break;
				
				case 4:
					System.out.print("C");
					break;
					
				case 5:
					System.out.print("D");
					break;
					
				case 6:
					System.out.print("E");
					break;
					
				case 9:
					System.out.print("F");
					break;
					
				case 10:
					System.out.print("G");
					break;
					
				case 11:
					System.out.print("H");
					break;
					
				
				default:
					System.out.print(" ");
					break;
				}
			}
			
			System.out.println();
			
			for (int i = 0; i < 10; i++) {
				
				System.out.println();
				System.out.print(i + " ");
				
				for (int j = 0; j < 11; j++) {
					if (economyGrid[i][j] == 0) {
						System.out.print("F");
					}
					else {
						System.out.print(" ");
					}
				}
				
			
			}
			
			System.out.println();
	}
}


