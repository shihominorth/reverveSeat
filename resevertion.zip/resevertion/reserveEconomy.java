package resevertion;
import java.util.Scanner;

public class reserveEconomy {
	static Scanner sc = new Scanner(System.in);
	static table table = new table();
	static reserveEconomy reserveEconomy = new reserveEconomy();
	static String alphabet;
	static int num;
	static int x;
	static int y;
	
	public static void reserve() {
		System.out.println();
		System.out.println("Where do you want to make a reserve?");
		
		System.out.println("Which alphabet is the seat you want?");
		alphabet = sc.next();
		
		System.out.println("Which number is the seat you want?");
		num = sc.nextInt();
		
		if (alphabet.equals("A")) {
			x = 0;
		} 
		else if (alphabet.equals("B")) {
			x = 1;
		}
		else if (alphabet.equals("C")) {
			x = 4;
		}
		else if (alphabet.equals("D")) {
			x = 5;
		}
		else if (alphabet.equals("E")) {
			x = 6;
		}
		else if (alphabet.equals("F")) {
			x = 9;
		}
		else if (alphabet.equals("G")) {
			x = 10;
		}
		else {
			reserveEconomy.reserve();
		}
		
		if( num < 10) {
			y = num;
		} else {
			reserveEconomy.reserve();
		}
	}
	
	public static void initReserve() {
		
		if (table.economyGrid[y][x] == 0) {
			table.economyGrid[y][x] = 1;	
		}
		
	}
	
	public static void initAll() {
		for (int x = 0; x < 10; x++) {
			for (int y = 0; y < 11; y++) {
				table.economyGrid[y][x] = 1;
			}
		}
	}
	
	public static void reservedSeat() {
		
		System.out.println();
		System.out.println();
		System.out.println("Economy");
		System.out.println();
	
		for (int i = 0; i < 11; i++) {
			
			switch (i) {
			case 0:
				System.out.print("  A");
				break;

			case 1:
				System.out.print("B");
				break;
			
			case 4:
				System.out.print("C");
				break;
				
			case 5:
				System.out.print("D");
				break;
				
			case 6:
				System.out.print("E");
				break;
				
			case 9:
				System.out.print("F");
				break;
				
			case 10:
				System.out.print("G");
				break;
				
			case 11:
				System.out.print("H");
				break;
				
			
			default:
				System.out.print(" ");
				break;
			}
		}
		
		System.out.println();
		
		for (int i = 0; i < 10; i++) {
			
			System.out.println();
			System.out.print(i + " ");
			
			for (int j = 0; j < 11; j++) {
				if (table.economyGrid[i][j] == 0) {
					System.out.print("F");
				}
				else if (table.economyGrid[i][j] == 1) {
					System.out.print("@");
				}
				else {
					System.out.print(" ");
				}
			}
			
		
		}
		
		System.out.println();
		
		}
	
}
