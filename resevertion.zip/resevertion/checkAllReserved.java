package resevertion;

import java.util.Scanner;

public class checkAllReserved {
	
	static Scanner sc = new Scanner(System.in);
	static askClass askClass = new askClass();
	static reserveEconomy reserveEconomy = new reserveEconomy();
	static reserveFirst reserveFirst = new reserveFirst();
	
	public static void checkAllReservedEconomy() {
		for (int x = 0; x < 10; x++) {
			for (int y = 0; y < 11; y++) {
				if(table.economyGrid[y][x] == 1) {
					System.out.println("All seats are reserved.");
				} else {
					System.out.println("Do you want to reserve more seats? Answer yes or no");
					String yesNo = sc.next();
					
					if (yesNo.equals("yes")) {
						askClass.askClass();
					} 
					else if (yesNo.equals("no")) {
						reserveFirst.reservedSeat();
						reserveEconomy.reservedSeat();
					}
				}
			}
		}
	}
	
	public static void checkAllReserveFirst() {
		for (int x = 0; x < 12; x++) {
			for (int y = 0; y < 4; y++) {
				if(table.firstClassGrid[y][x] == 1) {
					System.out.println("All seats are reserved.");
				} else {
					System.out.println("Do you want to reserve more seats? Answer yes or no");
					String yesNo = sc.next();
					
					if (yesNo.equals("yes")) {
						askClass.askClass();
					} 
					else if (yesNo.equals("no")) {
						reserveFirst.reservedSeat();
						reserveEconomy.reservedSeat();
					}
				}
			}
		}
	}
}
