package resevertion;
import java.util.Scanner;

public class askClass {
	static Scanner sc = new Scanner(System.in);
	static askClass  askClass = new askClass();
	static table table = new table();
	static reserveEconomy reserveEconomy = new reserveEconomy();
	static reserveFirst reserveFirst = new reserveFirst();
	static checkAllReserved checkAllReserved = new checkAllReserved();
	
	
	public static void askClass() {
		
		System.out.println();
		System.out.println("Which class would you like to reserve a seat?");
		String isClass = sc.nextLine();
		
		if (isClass.equals("first")) {
			
			table.firstClassSeat();
			reserveFirst.reserve();
			reserveFirst.initReserve();
			reserveFirst.reservedSeat();
			checkAllReserved.checkAllReserveFirst();
			
			
			
		} 
		else if ( isClass.equals("economy")){
			
			table.economySeat();
			reserveEconomy.reserve();
			reserveEconomy.initReserve();
			reserveEconomy.reservedSeat();
			checkAllReserved.checkAllReservedEconomy();
			
			
		} else {
			askClass.askClass();
			
		}
	}
}
